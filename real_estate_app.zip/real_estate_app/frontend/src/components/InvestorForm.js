// React component for adding investor
