// React component for adding land
