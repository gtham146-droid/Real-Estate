// Main React app component
