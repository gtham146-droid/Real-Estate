# Flask backend with SQLite and profit calculation logic
